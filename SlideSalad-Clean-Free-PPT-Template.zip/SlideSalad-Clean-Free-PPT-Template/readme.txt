SlideSalad Marketplace
========================
Thanks for downloading our free templates

Find more Professional PowerPoint, Google Slides and Keynote templates at:
www.SlideSalad.com

Templates On Sale:
https://www.slidesalad.com/templates-on-sale/


Featured Templates:
https://www.slidesalad.com/featured-templates/



SlideSalad is #1 online marketplace of premium presentations templates for all needs.
Please contact us if you have any further questions: support@slidesalad.com

Best Regards,
SlideSalad Team.

==== SlideSalad.com ====

